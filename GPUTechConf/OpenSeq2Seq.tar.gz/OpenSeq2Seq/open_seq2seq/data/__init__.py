# Copyright (c) 2017 NVIDIA Corporation
from .data_layer import DataLayer, ParallelDataInRamInputLayer
from .utils import weighted_choice, pretty_print_array